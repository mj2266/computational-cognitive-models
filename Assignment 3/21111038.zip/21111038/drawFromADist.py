import numpy as np


def drawFromADist(p):
    if (np.sum(p) == 0):
        p = 0.05*np.ones(p.shape[0])

    p = p/np.sum(p)
    c = np.cumsum(p)
    rand = np.random.random(1)
    idx = np.where((rand-np.cumsum(p))<0)
    sample = np.min(idx)

    out = np.zeros(p.shape[0])
    out[sample] = 1.0

    return out
